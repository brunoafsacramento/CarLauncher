# Car Launcher

Launcher Android para central multimídia: tela inicial com relógio, controle de música,
atalhos de apps e, quando houver um ELM327 conectado, painel do motor e leitura/limpeza de erros.
Funciona normalmente sem OBD.

## Abas
- **Início**: relógio, música tocando (voltar, tocar/pausar, avançar), carro animado e barra de atalhos.
- **Apps**: todos os apps instalados, com busca. Segure um app para fixá-lo ou tirá-lo do Início.
- **Motor**: mostradores de rotação, velocidade e temperatura, e botão para conectar ao ELM327.
- **Erros**: lê e apaga os códigos de erro da injeção.

## Primeiro uso
1. Aperte Home e escolha "Car Launcher" como tela inicial.
2. Para mostrar o nome da música, toque no cartão de música e libere o acesso às notificações.
3. Para o OBD, pareie o ELM327 no Bluetooth da central (PIN 1234 ou 0000) e toque em "Conectar ao carro" na aba Motor.

## Estrutura do código
- `ui/`: telas e efeitos visuais (`Common.kt` tem o tema e o efeito de vidro; `CarHero.kt` desenha o carro).
- `apps/`: lista de apps instalados e atalhos sugeridos.
- `media/`: música tocando e botões de mídia.
- `obd/`: comunicação com o ELM327.
