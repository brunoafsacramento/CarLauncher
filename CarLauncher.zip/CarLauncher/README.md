# Car Launcher (ELM327 Bluetooth)

Launcher Android para central multimídia com painel OBD2, leitura e limpeza de códigos de erro.

## Como usar
1. Abra a pasta no Android Studio e aguarde a sincronização do Gradle.
2. Pareie o ELM327 nas configurações de Bluetooth da central (PIN 1234 ou 0000).
3. Instale o app, toque em "Conectar OBD" e escolha o adaptador (com a ignição ligada).
4. Aperte o botão Home e escolha "Car Launcher" como tela inicial.

## Estrutura
- `obd/ObdTransport.kt`: canal de comunicação (Bluetooth hoje; crie outra implementação para USB).
- `obd/ElmClient.kt`: comandos do ELM327, dados ao vivo, leitura e limpeza de erros.
- `obd/DtcDescriptions.kt`: tabela de descrições dos códigos.
- `MainViewModel.kt`: conexão, reconexão automática e estado da tela.
- `MainActivity.kt`: telas (Painel, Erros, Apps).
