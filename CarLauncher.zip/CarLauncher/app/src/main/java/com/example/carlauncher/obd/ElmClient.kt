package com.example.carlauncher.obd

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException

data class LiveData(
    val rpm: Int? = null,
    val speed: Int? = null,
    val coolant: Int? = null,
    val intakeTemp: Int? = null,
    val load: Int? = null,
    val throttle: Int? = null,
    val voltage: String? = null,
)

data class Dtc(val code: String, val pending: Boolean) {
    val description: String get() = DtcDescriptions.of(code)
}

/** Fala o protocolo do ELM327: envia um comando e lê até o prompt '>'. */
class ElmClient(private val transport: ObdTransport) {
    private val mutex = Mutex()
    private var isCan = true
    var protocol: String = ""
        private set

    suspend fun connect() {
        transport.connect()
        send("ATZ", 8000)   // reset
        send("ATE0")        // sem eco
        send("ATL0")        // sem quebra de linha extra
        send("ATS0")        // sem espaços
        send("ATH0")        // sem cabeçalhos
        send("ATSP0")       // protocolo automático
        val first = send("0100", 20000) // força a busca do protocolo
        if (messages(first).none { it.startsWith("4100") })
            throw IOException("A ECU não respondeu. A ignição está ligada?")
        isCan = messages(send("ATDPN")).lastOrNull()?.lastOrNull()?.let { it in "6789ABC" } ?: true
        protocol = send("ATDP").replace("\r", "").replace("\n", "").trim()
    }

    fun close() = transport.close()

    suspend fun readLive(): LiveData = LiveData(
        rpm = pid("0C")?.takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) / 4 },
        speed = pid("0D")?.firstOrNull(),
        coolant = pid("05")?.firstOrNull()?.minus(40),
        intakeTemp = pid("0F")?.firstOrNull()?.minus(40),
        load = pid("04")?.firstOrNull()?.let { it * 100 / 255 },
        throttle = pid("11")?.firstOrNull()?.let { it * 100 / 255 },
        voltage = send("ATRV").replace("\r", "").replace("\n", "").trim().takeIf { it.endsWith("V") },
    )

    /** Erros confirmados (modo 03) + pendentes (modo 07). */
    suspend fun readDtcs(): List<Dtc> =
        (readMode("03", "43", false) + readMode("07", "47", true)).distinctBy { it.code }

    /** Apaga os erros e desliga a luz da injeção (modo 04). */
    suspend fun clearDtcs() {
        if (messages(send("04", 10000)).none { it.startsWith("44") })
            throw IOException("A ECU não confirmou a limpeza. Deixe a ignição ligada e o motor desligado.")
    }

    private suspend fun readMode(cmd: String, prefix: String, pending: Boolean): List<Dtc> =
        messages(send(cmd, 10000)).filter { it.startsWith(prefix) }.flatMap { msg ->
            // Em CAN, o byte após o prefixo é a quantidade de códigos
            val body = if (isCan) msg.drop(4) else msg.drop(2)
            body.chunked(4).filter { it.length == 4 && it != "0000" }.map { Dtc(decodeDtc(it), pending) }
        }

    private suspend fun pid(pid: String): List<Int>? {
        val msg = messages(send("01$pid")).firstOrNull { it.startsWith("41$pid") } ?: return null
        return msg.drop(4).chunked(2).filter { it.length == 2 }.map { it.toInt(16) }
    }

    private suspend fun send(cmd: String, timeoutMs: Long = 5000): String = withContext(Dispatchers.IO) {
        mutex.withLock {
            val inp = transport.input
            while (inp.available() > 0) inp.read() // descarta sobras
            transport.output.write("$cmd\r".toByteArray())
            transport.output.flush()
            val sb = StringBuilder()
            val deadline = System.currentTimeMillis() + timeoutMs
            while (true) {
                if (inp.available() > 0) {
                    val c = inp.read()
                    if (c == -1) throw IOException("Conexão encerrada")
                    if (c.toChar() == '>') break
                    sb.append(c.toChar())
                } else {
                    if (System.currentTimeMillis() > deadline) throw IOException("Adaptador não respondeu ($cmd)")
                    delay(10)
                }
            }
            sb.toString()
        }
    }

    companion object {
        private const val HEX = "0123456789ABCDEF"

        /** Extrai as respostas em hexadecimal, juntando respostas CAN de várias linhas ("0:", "1:"...). */
        fun messages(raw: String): List<String> {
            val out = mutableListOf<String>()
            var multi: StringBuilder? = null
            for (line in raw.split('\r', '\n')) {
                val l = line.replace(" ", "").uppercase()
                if (l.isEmpty()) continue
                if (l.length > 2 && l[1] == ':') {
                    if (l[0] == '0' || multi == null) {
                        multi?.let { out.add(it.toString()) }
                        multi = StringBuilder()
                    }
                    multi?.append(l.substring(2))
                } else if (l.length != 3 && l.all { it in HEX }) {
                    out.add(l)
                }
            }
            multi?.let { out.add(it.toString()) }
            return out
        }

        /** "0171" -> "P0171", "4123" -> "C0123" */
        fun decodeDtc(hex: String): String {
            val n = hex[0].digitToInt(16)
            return "PCBU"[n shr 2].toString() + (n and 3) + hex.substring(1)
        }
    }
}
