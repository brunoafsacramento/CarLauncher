package com.example.carlauncher.media

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.KeyEvent
import androidx.core.app.NotificationManagerCompat

/** Serviço vazio: existe só para o Android liberar a leitura da música que está tocando. */
class MediaListener : NotificationListenerService()

data class NowPlaying(val title: String?, val artist: String?, val playing: Boolean, val pkg: String?)

object MediaInfo {
    fun hasAccess(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    /** Retorna null quando o usuário ainda não autorizou o acesso. */
    fun read(context: Context): NowPlaying? {
        if (!hasAccess(context)) return null
        return try {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val session = manager.getActiveSessions(ComponentName(context, MediaListener::class.java)).firstOrNull()
                ?: return NowPlaying(null, null, false, null)
            val meta = session.metadata
            NowPlaying(
                title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE),
                artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST),
                playing = session.playbackState?.state == PlaybackState.STATE_PLAYING,
                pkg = session.packageName
            )
        } catch (_: Exception) {
            null
        }
    }

    /** Envia um botão de mídia (tocar/pausar, próxima, anterior) para o app que estiver tocando. */
    fun key(context: Context, code: Int) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun openAccessSettings(context: Context) {
        try {
            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (_: Exception) {
        }
    }
}
