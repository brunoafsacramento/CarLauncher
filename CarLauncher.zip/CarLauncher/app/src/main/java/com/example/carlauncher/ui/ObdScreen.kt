package com.example.carlauncher.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.carlauncher.MainViewModel

@Composable
fun ObdScreen(vm: MainViewModel, onConnectClick: () -> Unit) {
    val d = vm.live
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                Text("Motor", fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = Ui.Text)
                Text(vm.status, fontSize = 13.sp, color = Ui.TextDim, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            GlassButton(if (vm.active) "Desconectar" else "Conectar ao carro", onClick = onConnectClick)
        }
        Row(
            Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ArcGauge("Rotação", d.rpm?.toFloat(), 8000f, "rpm", Modifier.weight(1f).fillMaxHeight(), warnFrom = 6500f)
            ArcGauge("Velocidade", d.speed?.toFloat(), 220f, "km/h", Modifier.weight(1f).fillMaxHeight())
            ArcGauge("Temperatura", d.coolant?.toFloat(), 130f, "°C", Modifier.weight(1f).fillMaxHeight(), warnFrom = 105f)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Ar de admissão", d.intakeTemp?.let { "$it °C" }, Modifier.weight(1f))
            Stat("Carga do motor", d.load?.let { "$it %" }, Modifier.weight(1f))
            Stat("Borboleta", d.throttle?.let { "$it %" }, Modifier.weight(1f))
            Stat("Bateria", d.voltage, Modifier.weight(1f))
        }
    }
}

/** Mostrador em arco; o ponteiro desliza até o novo valor e fica vermelho na faixa de alerta. */
@Composable
private fun ArcGauge(
    label: String, value: Float?, max: Float, unit: String,
    modifier: Modifier = Modifier, warnFrom: Float? = null
) {
    val fraction by animateFloatAsState(
        targetValue = ((value ?: 0f) / max).coerceIn(0f, 1f),
        animationSpec = tween(400),
        label = "gauge"
    )
    val warn = value != null && warnFrom != null && value >= warnFrom
    val color by animateColorAsState(if (warn) Ui.Redline else Ui.Ice, label = "gaugeColor")

    Box(modifier.glass(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(16.dp)) {
            val d = minOf(size.width, size.height)
            val stroke = d * 0.07f
            val topLeft = Offset((size.width - d) / 2f + stroke / 2f, (size.height - d) / 2f + stroke / 2f)
            val arcSize = Size(d - stroke, d - stroke)
            drawArc(
                Color.White.copy(alpha = 0.09f), 135f, 270f, false,
                topLeft = topLeft, size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round)
            )
            if (fraction > 0.001f) {
                drawArc(
                    color.copy(alpha = 0.20f), 135f, 270f * fraction, false,
                    topLeft = topLeft, size = arcSize, style = Stroke(stroke * 2.2f, cap = StrokeCap.Round)
                )
                drawArc(
                    color, 135f, 270f * fraction, false,
                    topLeft = topLeft, size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                value?.toInt()?.toString() ?: "--",
                fontSize = 40.sp, fontWeight = FontWeight.Light, color = Ui.Text, maxLines = 1
            )
            Text(unit, fontSize = 14.sp, color = Ui.TextDim)
            Text(label, fontSize = 13.sp, color = Ui.TextDim)
        }
    }
}

@Composable
private fun Stat(label: String, value: String?, modifier: Modifier = Modifier) {
    Column(modifier.glass(RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text(label, fontSize = 12.sp, color = Ui.TextDim, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(value ?: "--", fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Ui.Text, maxLines = 1)
    }
}

@Composable
fun DtcScreen(vm: MainViewModel) {
    var confirm by remember { mutableStateOf(false) }
    val list = vm.dtcs
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                Text("Erros da injeção", fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = Ui.Text)
                Text(
                    vm.message ?: if (vm.busy) "Consultando a central…" else "Leia os códigos gravados na central do motor",
                    fontSize = 13.sp, color = Ui.TextDim, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            GlassButton("Ler erros", enabled = vm.connected && !vm.busy) { vm.readDtcs() }
            GlassButton("Apagar erros", enabled = vm.connected && !vm.busy) { confirm = true }
        }
        when {
            !vm.connected && list == null ->
                Text("Conecte ao carro na aba Motor para ler os erros.", color = Ui.TextDim, modifier = Modifier.padding(6.dp))
            list == null ->
                Text("Toque em “Ler erros” para consultar a central.", color = Ui.TextDim, modifier = Modifier.padding(6.dp))
            list.isEmpty() ->
                Text("Nenhum erro registrado.", color = Ui.Text, fontSize = 18.sp, modifier = Modifier.padding(6.dp))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list) { dtc ->
                    Row(
                        Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(dtc.code, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = if (dtc.pending) Ui.Ice else Ui.Redline)
                        Column(Modifier.weight(1f)) {
                            Text(dtc.description, color = Ui.Text, fontSize = 15.sp)
                            Text(if (dtc.pending) "Pendente" else "Confirmado", color = Ui.TextDim, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Apagar os erros?") },
            text = { Text("Deixe a ignição ligada e o motor desligado. Se o defeito for real, o erro volta. Anote os códigos antes.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    vm.clearDtcs()
                }) { Text("Apagar erros") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } }
        )
    }
}
