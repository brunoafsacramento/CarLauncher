package com.example.carlauncher

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.carlauncher.ui.AppsScreen
import com.example.carlauncher.ui.DtcScreen
import com.example.carlauncher.ui.GlassRail
import com.example.carlauncher.ui.HomeScreen
import com.example.carlauncher.ui.ObdScreen
import com.example.carlauncher.ui.SmokeBackground
import com.example.carlauncher.ui.Ui

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Apertar o botão Home com o launcher aberto volta para a aba Início
        addOnNewIntentListener { vm.tab = 0 }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Ui.Ice,
                    surface = Color(0xFF141A27),
                    onSurface = Ui.Text
                )
            ) {
                CompositionLocalProvider(LocalContentColor provides Ui.Text) {
                    Box(Modifier.fillMaxSize()) {
                        SmokeBackground()
                        LauncherRoot(vm)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.loadApps() // atualiza a lista caso algum app tenha sido instalado ou removido
    }
}

private fun bluetoothAdapter(context: Context): BluetoothAdapter? =
    (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

private fun hasBluetoothPermission(context: Context): Boolean =
    Build.VERSION.SDK_INT < 31 || ContextCompat.checkSelfPermission(
        context, Manifest.permission.BLUETOOTH_CONNECT
    ) == PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
@Composable
fun LauncherRoot(vm: MainViewModel) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("obd", Context.MODE_PRIVATE) }
    var showDevices by remember { mutableStateOf(false) }

    // Um launcher não fecha com o botão voltar: ele retorna para a aba Início
    BackHandler { vm.tab = 0 }

    val askPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) showDevices = true }

    // Reconecta sozinho ao último adaptador usado
    LaunchedEffect(Unit) {
        val address = prefs.getString("address", null)
        val adapter = bluetoothAdapter(context)
        if (!vm.active && address != null && adapter != null && hasBluetoothPermission(context)) {
            vm.connect(adapter.getRemoteDevice(address))
        }
    }

    val onConnectClick: () -> Unit = {
        if (vm.active) {
            vm.disconnect()
        } else if (hasBluetoothPermission(context)) {
            showDevices = true
        } else {
            askPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
    }

    val openSettings: () -> Unit = {
        try {
            context.startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (_: Exception) {
        }
    }

    Row(Modifier.fillMaxSize()) {
        GlassRail(tab = vm.tab, onTab = { vm.tab = it }, onSettings = openSettings)
        AnimatedContent(
            targetState = vm.tab,
            modifier = Modifier.weight(1f).fillMaxHeight(),
            transitionSpec = {
                (fadeIn(tween(260)) + slideInVertically(tween(260)) { it / 14 }) togetherWith fadeOut(tween(140))
            },
            label = "page"
        ) { page ->
            when (page) {
                0 -> HomeScreen(vm, onOpenObd = { vm.tab = 2 })
                1 -> AppsScreen(vm)
                2 -> ObdScreen(vm, onConnectClick)
                else -> DtcScreen(vm)
            }
        }
    }

    if (showDevices) {
        val devices = remember {
            if (hasBluetoothPermission(context))
                bluetoothAdapter(context)?.bondedDevices?.toList().orEmpty()
            else emptyList()
        }
        DeviceDialog(
            devices = devices,
            onPick = { device ->
                prefs.edit().putString("address", device.address).apply()
                showDevices = false
                vm.connect(device)
            },
            onDismiss = { showDevices = false }
        )
    }
}

@SuppressLint("MissingPermission")
@Composable
fun DeviceDialog(devices: List<BluetoothDevice>, onPick: (BluetoothDevice) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Escolha o adaptador OBD") },
        text = {
            if (devices.isEmpty()) {
                Text("Nenhum dispositivo pareado. Pareie o ELM327 nas configurações de Bluetooth da central (PIN 1234 ou 0000) e volte aqui.")
            } else {
                LazyColumn {
                    items(devices) { device ->
                        Text(
                            "${device.name ?: "Sem nome"}\n${device.address}",
                            Modifier.fillMaxWidth().clickable { onPick(device) }.padding(12.dp)
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}
