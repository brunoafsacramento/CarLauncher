package com.example.carlauncher

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.example.carlauncher.obd.LiveData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { LauncherApp(vm) }
            }
        }
    }
}

private fun bluetoothAdapter(context: Context): BluetoothAdapter? =
    (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

private fun hasBluetoothPermission(context: Context): Boolean =
    Build.VERSION.SDK_INT < 31 || ContextCompat.checkSelfPermission(
        context, Manifest.permission.BLUETOOTH_CONNECT
    ) == PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
@Composable
fun LauncherApp(vm: MainViewModel) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("obd", Context.MODE_PRIVATE) }
    var tab by remember { mutableIntStateOf(0) }
    var showDevices by remember { mutableStateOf(false) }

    BackHandler { /* um launcher não fecha com o botão voltar */ }

    val askPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) showDevices = true }

    // Reconecta sozinho ao último adaptador usado
    LaunchedEffect(Unit) {
        val address = prefs.getString("address", null)
        val adapter = bluetoothAdapter(context)
        if (!vm.active && address != null && adapter != null && hasBluetoothPermission(context)) {
            vm.connect(adapter.getRemoteDevice(address))
        }
    }

    Row(Modifier.fillMaxSize()) {
        NavigationRail {
            NavigationRailItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text("Painel") })
            NavigationRailItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Warning, null) }, label = { Text("Erros") })
            NavigationRailItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Menu, null) }, label = { Text("Apps") })
        }
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(vm.status, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                TextButton(onClick = {
                    when {
                        vm.active -> vm.disconnect()
                        hasBluetoothPermission(context) -> showDevices = true
                        else -> askPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
                    }
                }) { Text(if (vm.active) "Desconectar" else "Conectar OBD") }
                IconButton(onClick = { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }) {
                    Icon(Icons.Default.Settings, "Configurações do Android")
                }
            }
            when (tab) {
                0 -> Dashboard(vm.live)
                1 -> DtcScreen(vm)
                else -> AppsGrid()
            }
        }
    }

    if (showDevices) {
        val devices = remember {
            if (hasBluetoothPermission(context))
                bluetoothAdapter(context)?.bondedDevices?.toList().orEmpty()
            else emptyList()
        }
        DeviceDialog(
            devices = devices,
            onPick = {
                prefs.edit().putString("address", it.address).apply()
                showDevices = false
                vm.connect(it)
            },
            onDismiss = { showDevices = false }
        )
    }
}

@Composable
fun Dashboard(d: LiveData) {
    val cells = listOf(
        "Rotação" to d.rpm?.let { "$it rpm" },
        "Velocidade" to d.speed?.let { "$it km/h" },
        "Temp. do motor" to d.coolant?.let { "$it °C" },
        "Temp. do ar" to d.intakeTemp?.let { "$it °C" },
        "Carga do motor" to d.load?.let { "$it %" },
        "Borboleta" to d.throttle?.let { "$it %" },
        "Bateria" to d.voltage,
    )
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        gridItems(cells) { (label, value) ->
            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(label, fontSize = 14.sp)
                    Text(value ?: "--", fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun DtcScreen(vm: MainViewModel) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.readDtcs() }, enabled = vm.connected && !vm.busy) { Text("Ler erros") }
            OutlinedButton(onClick = { confirm = true }, enabled = vm.connected && !vm.busy) { Text("Apagar erros") }
            if (vm.busy) CircularProgressIndicator(Modifier.size(28.dp))
        }
        vm.message?.let { Text(it, color = MaterialTheme.colorScheme.tertiary) }
        val list = vm.dtcs
        when {
            !vm.connected && list == null -> Text("Conecte ao adaptador OBD para ler os erros.")
            list == null -> Text("Toque em “Ler erros” para consultar a central.")
            list.isEmpty() -> Text("Nenhum erro registrado.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list) { dtc ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(
                                dtc.code + if (dtc.pending) "  (pendente)" else "",
                                fontSize = 20.sp, fontWeight = FontWeight.Bold
                            )
                            Text(dtc.description)
                        }
                    }
                }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Apagar os erros?") },
            text = { Text("Deixe a ignição ligada e o motor desligado. Se o defeito for real, o erro volta. Anote os códigos antes.") },
            confirmButton = { TextButton(onClick = { confirm = false; vm.clearDtcs() }) { Text("Apagar") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } }
        )
    }
}

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

private fun loadApps(context: Context): List<AppInfo> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                pkg = it.activityInfo.packageName,
                icon = it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
            )
        }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun AppsGrid() {
    val context = LocalContext.current
    val apps by produceState(emptyList<AppInfo>()) {
        value = withContext(Dispatchers.IO) { loadApps(context) }
    }
    LazyVerticalGrid(columns = GridCells.Adaptive(110.dp), contentPadding = PaddingValues(12.dp)) {
        gridItems(apps) { app ->
            Column(
                Modifier
                    .clickable {
                        context.packageManager.getLaunchIntentForPackage(app.pkg)?.let { context.startActivity(it) }
                    }
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(app.icon, null, Modifier.size(56.dp))
                Spacer(Modifier.size(6.dp))
                Text(app.label, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun DeviceDialog(devices: List<BluetoothDevice>, onPick: (BluetoothDevice) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Escolha o adaptador OBD") },
        text = {
            if (devices.isEmpty()) {
                Text("Nenhum dispositivo pareado. Pareie o ELM327 nas configurações de Bluetooth da central (PIN 1234 ou 0000) e volte aqui.")
            } else {
                LazyColumn {
                    items(devices) { d ->
                        Text(
                            "${d.name ?: "Sem nome"}\n${d.address}",
                            Modifier.fillMaxWidth().clickable { onPick(d) }.padding(12.dp)
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}
