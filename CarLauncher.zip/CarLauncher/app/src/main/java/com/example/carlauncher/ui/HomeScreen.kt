package com.example.carlauncher.ui

import android.view.KeyEvent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.carlauncher.MainViewModel
import com.example.carlauncher.apps.AppInfo
import com.example.carlauncher.apps.launchApp
import com.example.carlauncher.media.MediaInfo
import com.example.carlauncher.media.NowPlaying
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun HomeScreen(vm: MainViewModel, onOpenObd: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ClockBlock()
                MediaCard(Modifier.weight(1f).fillMaxWidth())
            }
            Box(Modifier.weight(1.4f).fillMaxHeight()) {
                CarHero(Modifier.fillMaxSize(), moving = (vm.live.speed ?: 0) > 0)
                ObdChips(vm, onOpenObd, Modifier.align(Alignment.TopEnd))
            }
        }
        Dock(vm)
    }
}

@Composable
private fun ClockBlock() {
    val locale = remember { Locale("pt", "BR") }
    val timeFormat = remember { SimpleDateFormat("HH:mm", locale) }
    val dateFormat = remember { SimpleDateFormat("EEEE, d 'de' MMMM", locale) }
    val now by produceState(Date()) {
        while (true) {
            value = Date()
            delay(1000)
        }
    }
    Column(Modifier.padding(start = 6.dp)) {
        Text(
            timeFormat.format(now),
            fontSize = 60.sp,
            fontWeight = FontWeight.Light,
            color = Ui.Text,
            maxLines = 1
        )
        Text(
            dateFormat.format(now).replaceFirstChar { it.uppercase() },
            fontSize = 15.sp,
            color = Ui.TextDim,
            maxLines = 1
        )
    }
}

@Composable
private fun MediaCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val nowPlaying by produceState<NowPlaying?>(null) {
        while (true) {
            value = MediaInfo.read(context)
            delay(1000)
        }
    }
    val info = nowPlaying
    val title = when {
        info == null -> "Controle de música"
        info.title.isNullOrBlank() -> "Nada tocando"
        else -> info.title.orEmpty()
    }
    val subtitle = when {
        info == null -> "Toque aqui para mostrar o nome da música"
        info.title.isNullOrBlank() -> "Abra o rádio ou um app de música"
        else -> info.artist ?: ""
    }
    Column(
        modifier.glass().padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            Modifier.fillMaxWidth().pressable {
                if (info == null) MediaInfo.openAccessSettings(context)
                else info.pkg?.let { launchApp(context, it) }
            },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = Ui.Text,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    subtitle, fontSize = 14.sp, color = Ui.TextDim,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (info?.playing == true) {
                Spacer(Modifier.width(10.dp))
                EqualizerBars()
            }
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MediaButton(Glyph.Previous) { MediaInfo.key(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
            MediaButton(if (info?.playing == true) Glyph.Pause else Glyph.Play, big = true) {
                MediaInfo.key(context, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            }
            MediaButton(Glyph.Next) { MediaInfo.key(context, KeyEvent.KEYCODE_MEDIA_NEXT) }
        }
    }
}

private enum class Glyph { Previous, Play, Pause, Next }

@Composable
private fun MediaButton(glyph: Glyph, big: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .size(if (big) 62.dp else 50.dp)
            .pressable(onClick = onClick)
            .glass(CircleShape, tint = if (big) Ui.Ice else Color.White, strength = if (big) 1.8f else 1f),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(if (big) 22.dp else 18.dp)) { drawGlyph(glyph, Ui.Text) }
    }
}

private fun DrawScope.drawGlyph(glyph: Glyph, color: Color) {
    val w = size.width
    val h = size.height
    fun triangle(base: Float, tip: Float) = Path().apply {
        moveTo(base, 0f)
        lineTo(tip, h / 2f)
        lineTo(base, h)
        close()
    }
    when (glyph) {
        Glyph.Play -> drawPath(triangle(w * 0.18f, w * 0.98f), color)
        Glyph.Pause -> {
            drawRect(color, Offset(w * 0.12f, 0f), Size(w * 0.26f, h))
            drawRect(color, Offset(w * 0.62f, 0f), Size(w * 0.26f, h))
        }
        Glyph.Next -> {
            drawPath(triangle(0f, w * 0.72f), color)
            drawRect(color, Offset(w * 0.80f, 0f), Size(w * 0.16f, h))
        }
        Glyph.Previous -> {
            drawPath(triangle(w, w * 0.28f), color)
            drawRect(color, Offset(w * 0.04f, 0f), Size(w * 0.16f, h))
        }
    }
}

/** Barrinhas que dançam enquanto há música tocando. */
@Composable
private fun EqualizerBars() {
    val transition = rememberInfiniteTransition(label = "eq")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
        label = "eqPhase"
    )
    Canvas(Modifier.size(24.dp, 18.dp)) {
        val bar = size.width / 7f
        for (i in 0 until 4) {
            val level = 0.30f + 0.70f * abs(sin(2f * PI.toFloat() * (phase.value + i * 0.23f)))
            val barHeight = size.height * level
            drawRoundRect(
                Ui.Ice,
                Offset(i * bar * 2f, size.height - barHeight),
                Size(bar, barHeight),
                CornerRadius(bar / 2f)
            )
        }
    }
}

@Composable
private fun ObdChips(vm: MainViewModel, onOpenObd: () -> Unit, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (vm.connected) {
            val d = vm.live
            Chip("${d.speed ?: "--"} km/h", Ui.Ice, onOpenObd)
            Chip("${d.rpm ?: "--"} rpm", Ui.Ice, onOpenObd)
            Chip("${d.coolant ?: "--"} °C", if ((d.coolant ?: 0) >= 105) Ui.Redline else Ui.Ice, onOpenObd)
        } else {
            Chip(if (vm.active) "Conectando ao carro…" else "Carro desconectado", Ui.TextDim, onOpenObd)
        }
    }
}

@Composable
private fun Chip(text: String, dot: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .pressable(onClick = onClick)
            .glass(RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(dot, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 14.sp, color = Ui.Text, maxLines = 1)
    }
}

/** Barra de atalhos: os apps fixados pelo usuário (ou os sugeridos, se ele ainda não escolheu). */
@Composable
private fun Dock(vm: MainViewModel) {
    val context = LocalContext.current
    val favorites = vm.favoriteApps
    Box(
        Modifier.fillMaxWidth().height(94.dp).glass(RoundedCornerShape(30.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (favorites.isEmpty()) {
            Text(
                "Segure um app na aba Apps para fixá-lo aqui",
                color = Ui.TextDim, fontSize = 14.sp, modifier = Modifier.padding(16.dp)
            )
        } else {
            LazyRow(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(favorites, key = { it.pkg }) { app ->
                    DockItem(app) { launchApp(context, app.pkg) }
                }
            }
        }
    }
}

@Composable
private fun DockItem(app: AppInfo, onClick: () -> Unit) {
    Column(
        Modifier.width(96.dp).pressable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(app.icon, null, Modifier.size(50.dp))
        Spacer(Modifier.height(4.dp))
        Text(app.label, fontSize = 12.sp, color = Ui.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
