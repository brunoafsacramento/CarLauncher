package com.example.carlauncher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Cores do tema: noite de garagem, fumaça azul-aço e o azul-gelo de painel digital. */
object Ui {
    val NightTop = Color(0xFF0B1020)
    val NightBottom = Color(0xFF04060B)
    val Smoke = Color(0xFF5B6B8C)
    val Ice = Color(0xFF7FD6FF)
    val Redline = Color(0xFFFF5A4F)
    val Text = Color(0xFFF1F5FC)
    val TextDim = Color(0xFF98A4BA)
}

/**
 * Efeito de vidro: preenchimento translúcido + borda com brilho.
 * Não usa desfoque real de propósito, para rodar liso em centrais fracas.
 */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(26.dp),
    tint: Color = Color.White,
    strength: Float = 1f
): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(tint.copy(alpha = 0.13f * strength), tint.copy(alpha = 0.04f * strength))
        )
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.40f),
                Color.White.copy(alpha = 0.04f),
                Color.White.copy(alpha = 0.16f)
            )
        ),
        shape
    )

/** Toque com animação: o item encolhe um pouco ao ser pressionado e volta com efeito de mola. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.pressable(onLongClick: (() -> Unit)? = null, onClick: () -> Unit): Modifier = composed {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "press"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .combinedClickable(
            interactionSource = interaction,
            indication = null,
            onLongClick = onLongClick,
            onClick = onClick
        )
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier
            .pressable { if (enabled) onClick() }
            .glass(RoundedCornerShape(50), tint = Ui.Ice, strength = if (enabled) 1.6f else 0.5f)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) Ui.Text else Ui.TextDim, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

/** Mancha circular suave de raio 1, para ser esticada e movida sem recriar o pincel a cada quadro. */
fun softBlob(color: Color, alpha: Float): Brush = Brush.radialGradient(
    listOf(color.copy(alpha = alpha), color.copy(alpha = alpha * 0.35f), Color.Transparent),
    center = Offset.Zero,
    radius = 1f
)
