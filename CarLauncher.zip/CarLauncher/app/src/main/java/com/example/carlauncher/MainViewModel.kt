package com.example.carlauncher

import android.app.Application
import android.bluetooth.BluetoothDevice
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.carlauncher.apps.AppInfo
import com.example.carlauncher.apps.AppRepo
import com.example.carlauncher.obd.BluetoothTransport
import com.example.carlauncher.obd.Dtc
import com.example.carlauncher.obd.ElmClient
import com.example.carlauncher.obd.LiveData
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    // ---------- Navegação ----------
    var tab by mutableIntStateOf(0)

    // ---------- Apps e atalhos ----------
    var apps by mutableStateOf<List<AppInfo>>(emptyList()); private set
    var favorites by mutableStateOf<List<String>>(emptyList()); private set

    private val prefs = app.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    /** Apps fixados na tela inicial, na ordem em que foram fixados. */
    val favoriteApps: List<AppInfo>
        get() = favorites.mapNotNull { pkg -> apps.firstOrNull { it.pkg == pkg } }

    fun loadApps() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { AppRepo.load(getApplication<Application>()) }
            apps = list
            // Enquanto o usuário não fixar nada, usa os apps sugeridos (rádio, música, mapas...)
            favorites = prefs.getString("favorites", null)?.split('|')?.filter { it.isNotEmpty() }
                ?: AppRepo.defaultFavorites(list)
        }
    }

    fun toggleFavorite(pkg: String) {
        val updated = if (pkg in favorites) favorites - pkg else favorites + pkg
        favorites = updated
        prefs.edit().putString("favorites", updated.joinToString("|")).apply()
    }

    // ---------- OBD ----------
    var status by mutableStateOf("Sem conexão com o carro"); private set
    var connected by mutableStateOf(false); private set
    var active by mutableStateOf(false); private set
    var live by mutableStateOf(LiveData()); private set
    var dtcs by mutableStateOf<List<Dtc>?>(null); private set
    var busy by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null); private set

    private var elm: ElmClient? = null
    private var job: Job? = null

    /** Conecta e fica lendo os dados. Se a conexão cair, tenta de novo a cada 5 s. */
    fun connect(device: BluetoothDevice) {
        disconnect()
        active = true
        job = viewModelScope.launch {
            while (isActive) {
                val client = ElmClient(BluetoothTransport(device))
                try {
                    status = "Conectando…"
                    client.connect()
                    elm = client
                    connected = true
                    status = "Conectado: ${client.protocol}"
                    while (isActive) {
                        live = client.readLive()
                        delay(200)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    status = "Sem resposta (${e.message ?: e.javaClass.simpleName}). Tentando de novo…"
                } finally {
                    client.close()
                    elm = null
                    connected = false
                    live = LiveData()
                }
                delay(5000)
            }
        }
    }

    fun disconnect() {
        job?.cancel()
        job = null
        active = false
        status = "Sem conexão com o carro"
    }

    fun readDtcs() = op {
        val c = elm ?: error("Conecte ao carro primeiro")
        dtcs = c.readDtcs()
    }

    fun clearDtcs() = op {
        val c = elm ?: error("Conecte ao carro primeiro")
        c.clearDtcs()
        dtcs = c.readDtcs()
        message = "Erros apagados"
    }

    private fun op(block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            message = null
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = e.message ?: "Falha na comunicação"
            } finally {
                busy = false
            }
        }
    }

    override fun onCleared() {
        elm?.close()
    }
}
