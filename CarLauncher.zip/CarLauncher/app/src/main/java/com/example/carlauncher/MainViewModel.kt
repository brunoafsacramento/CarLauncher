package com.example.carlauncher

import android.bluetooth.BluetoothDevice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.carlauncher.obd.BluetoothTransport
import com.example.carlauncher.obd.Dtc
import com.example.carlauncher.obd.ElmClient
import com.example.carlauncher.obd.LiveData
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    var status by mutableStateOf("Desconectado"); private set
    var connected by mutableStateOf(false); private set
    var active by mutableStateOf(false); private set
    var live by mutableStateOf(LiveData()); private set
    var dtcs by mutableStateOf<List<Dtc>?>(null); private set
    var busy by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null); private set

    private var elm: ElmClient? = null
    private var job: Job? = null

    /** Conecta e fica lendo os dados. Se a conexão cair, tenta de novo a cada 5 s. */
    fun connect(device: BluetoothDevice) {
        disconnect()
        active = true
        job = viewModelScope.launch {
            while (isActive) {
                val client = ElmClient(BluetoothTransport(device))
                try {
                    status = "Conectando…"
                    client.connect()
                    elm = client
                    connected = true
                    status = "Conectado · ${client.protocol}"
                    while (isActive) {
                        live = client.readLive()
                        delay(200)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    status = "Erro: ${e.message ?: e.javaClass.simpleName}. Tentando de novo…"
                } finally {
                    client.close()
                    elm = null
                    connected = false
                    live = LiveData()
                }
                delay(5000)
            }
        }
    }

    fun disconnect() {
        job?.cancel()
        job = null
        active = false
        status = "Desconectado"
    }

    fun readDtcs() = op {
        val c = elm ?: error("Conecte ao adaptador primeiro")
        dtcs = c.readDtcs()
    }

    fun clearDtcs() = op {
        val c = elm ?: error("Conecte ao adaptador primeiro")
        c.clearDtcs()
        dtcs = c.readDtcs()
        message = "Erros apagados"
    }

    private fun op(block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            message = null
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = e.message ?: "Falha na comunicação"
            } finally {
                busy = false
            }
        }
    }

    override fun onCleared() {
        elm?.close()
    }
}
