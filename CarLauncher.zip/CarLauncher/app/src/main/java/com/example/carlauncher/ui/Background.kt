package com.example.carlauncher.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private class Blob(
    val x: Float, val y: Float, val radius: Float,
    val kx: Int, val ky: Int, val offset: Float, val brush: Brush
)

/** Fundo com fumaça em movimento lento: poucas manchas grandes e suaves, baratas de desenhar. */
@Composable
fun SmokeBackground(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "smoke")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(48_000, easing = LinearEasing)),
        label = "smokePhase"
    )
    val base = remember { Brush.verticalGradient(listOf(Ui.NightTop, Ui.NightBottom)) }
    val blobs = remember {
        listOf(
            Blob(0.18f, 0.30f, 0.42f, 1, 2, 0.0f, softBlob(Ui.Smoke, 0.34f)),
            Blob(0.62f, 0.72f, 0.50f, 2, 1, 1.7f, softBlob(Ui.Smoke, 0.28f)),
            Blob(0.86f, 0.22f, 0.36f, 1, 3, 3.1f, softBlob(Color(0xFF2E5C8A), 0.30f)),
            Blob(0.40f, 0.88f, 0.34f, 3, 2, 4.4f, softBlob(Color(0xFF8E9BB5), 0.16f)),
            Blob(0.72f, 0.45f, 0.30f, 2, 3, 5.2f, softBlob(Ui.Ice, 0.10f)),
        )
    }
    Canvas(modifier.fillMaxSize()) {
        drawRect(base)
        val p = phase.value * 2f * PI.toFloat()
        for (b in blobs) {
            val cx = (b.x + 0.11f * sin(p * b.kx + b.offset)) * size.width
            val cy = (b.y + 0.13f * cos(p * b.ky + b.offset)) * size.height
            val r = b.radius * size.width
            withTransform({
                translate(cx, cy)
                scale(r, r, Offset.Zero)
            }) {
                drawCircle(b.brush, 1f, Offset.Zero)
            }
        }
    }
}
