package com.example.carlauncher.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Barra lateral de vidro com as abas do launcher. */
@Composable
fun GlassRail(tab: Int, onTab: (Int) -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier
            .fillMaxHeight()
            .padding(start = 12.dp, top = 12.dp, bottom = 12.dp)
            .width(78.dp)
            .glass(RoundedCornerShape(30.dp))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        RailItem(Icons.Default.Home, "Início", tab == 0) { onTab(0) }
        RailItem(Icons.Default.Menu, "Apps", tab == 1) { onTab(1) }
        RailItem(Icons.Default.Build, "Motor", tab == 2) { onTab(2) }
        RailItem(Icons.Default.Warning, "Erros", tab == 3) { onTab(3) }
        Spacer(Modifier.weight(1f))
        RailItem(Icons.Default.Settings, "Ajustes", false, onSettings)
    }
}

@Composable
private fun RailItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val background by animateColorAsState(
        if (selected) Ui.Ice.copy(alpha = 0.20f) else Color.Transparent, label = "railBackground"
    )
    val content by animateColorAsState(if (selected) Ui.Ice else Ui.TextDim, label = "railContent")
    Column(
        Modifier
            .padding(vertical = 3.dp)
            .pressable(onClick = onClick)
            .clip(RoundedCornerShape(20.dp))
            .background(background)
            .width(64.dp)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = content, modifier = Modifier.size(24.dp))
        Text(label, fontSize = 11.sp, color = content, maxLines = 1)
    }
}
